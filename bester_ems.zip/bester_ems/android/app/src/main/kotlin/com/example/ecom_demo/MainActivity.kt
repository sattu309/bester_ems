package com.bester.besterems

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
